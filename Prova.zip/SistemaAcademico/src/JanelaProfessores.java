import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author professor
 */
public class JanelaProfessores extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(JanelaProfessores.class.getName());

    // Usuário
    String usuario = "root";

    // Senha
    String senha = "etec123";

    // Banco de dados
    String banco = "etec";
        
    // Servidor de banco de dados
    String servidor = "127.0.0.1";

    // Endereço de conexão com Servidor de Banco de Dados
    String url = "jdbc:mysql://"+servidor+"/"+banco;
    
    // Variáveis para armazenar temporariamente um novo professor recem inserido
    String codigo;
    String nome;

    // Criando variavel que representara a conexao com o SGBD
    Connection conexao;            
    
    private void consultarProfessores(){
        int totalProfessores=0;
        
        // Consulta que será enviada ao SGBD
        String sqlConsulta = "SELECT * from professor";

        // Criando objeto modelo que representará o objeto tabelaProfessores
        DefaultTableModel model = (DefaultTableModel) tabelaProfessores.getModel();

        // Zerando o número de linhas da tabela
        model.setRowCount(0);
        
        // Tente executar os comandos abaixo
        try {
            // Conectando ao SGBD
            conexao = DriverManager.getConnection(url, usuario, senha);

            // Preparando a consulta que será enviada ao SGBD
            PreparedStatement stmtSelect = conexao.prepareStatement(sqlConsulta);

            // Executando a consulta
            ResultSet rs = stmtSelect.executeQuery();

            
            // Enquanto a consulta enviada enviar algum registro (linha), faça
            while (rs.next()) {
                // Pegando o valor da coluna "codigo" da linha retornada e guardando na variável rm
                codigo = rs.getString("codigo");

                // Pegando o valor da coluna "nome" da linha retornada e guardando na variável nome
                nome = rs.getString("nome");
                
                // Adicionando na tabela os valores de rm e nome
                model.addRow(new Object[]{codigo, nome});

                totalProfessores++;
            }
            
            campoTotalProfessores.setText(""+totalProfessores);
             
            // Fechando conexao com Servidor de Banco de dados
            conexao.close();

        } 
        // Caso os comandos acima apresentem erros, capture o erro e exiba uma janela apresentado o erro
        catch (SQLException e) {
            // Crie uma janela para exibir a mensagem de erro.
            JOptionPane.showMessageDialog(botaoConsultaProfessores, "Erro ao consultar o banco: " + e.getMessage());
        }
       
       
    }
    
    private int excluirProfessor(String rm){

        // Exclusao que será enviada ao SGBD
        String sqlExclusao = "delete from professor where codigo = ?";

        // Armazenara a quantidade de registros excluidos e que sera retornado por esta função para quem chamou ela.
        int registrosExcluidos=0;
        
        
        // Tente executar os comandos abaixo
        try {
            // Conectando ao SGBD
            conexao = DriverManager.getConnection(url, usuario, senha);

            // Preparando a exclusao que será enviada ao SGBD
            PreparedStatement stmtDelete = conexao.prepareStatement(sqlExclusao);

            // Atribuindo o valor do rm no primeiro parametro da exclusao preparada acima
            stmtDelete.setString(1, codigo);
            
            // Executando a exclusao
            registrosExcluidos = stmtDelete.executeUpdate();

            // Fechando conexao com Servidor de Banco de dados
            conexao.close();
            
        } 
        
        // Caso os comandos acima apresentem erros, capture o erro e exiba uma janela apresentado o erro
        catch (SQLException e) {
            // Crie uma janela para exibir a mensagem de erro.
            JOptionPane.showMessageDialog(botaoConsultaProfessores, "Erro ao excluir registro: " + e.getMessage());
        }
       
        return registrosExcluidos;
        
    }

    private int inserirProfessor(String codigo, String nome){

        // Exclusao que será enviada ao SGBD
        String sqlInsercao = "insert into professor (codigo,nome) values (?,?)";

        // Armazena a quantidade registros que foram inseridos
        int registrosInseridos=0;
        
        // Tente executar os comandos abaixo
        try {
            // Conectando ao SGBD
            conexao = DriverManager.getConnection(url, usuario, senha);

            // Preparando a exclusao que será enviada ao SGBD
            PreparedStatement stmtInsert = conexao.prepareStatement(sqlInsercao);

            // Atribuindo o valor do codigo no primeiro parametro da insercao preparada acima
            stmtInsert.setString(1, codigo);

            // Atribuindo o valor do nome no segundo parametro da insercao preparada acima
            stmtInsert.setString(2, nome);
            
            // Executando a exclusao
            registrosInseridos = stmtInsert.executeUpdate();

            // Fechando conexao com Servidor de Banco de dados
            conexao.close();
            
        } 
        
        
        // Caso os comandos acima apresentem erros, capture o erro e exiba uma janela apresentado o erro
        catch (SQLException error) {
            // Crie uma janela para exibir a mensagem de erro.
            if ( error.getErrorCode() == 1062 ) {
                JOptionPane.showMessageDialog(botaoConsultaProfessores, "Código já cadastrado");
            }
            else {
                JOptionPane.showMessageDialog(botaoConsultaProfessores, "Erro ao inserir registro: " + error.getMessage());
            }
            
        }
       
        return registrosInseridos;
        
    }    

    private int alterarProfessor(String codigo,  String nome){

        // Exclusao que será enviada ao SGBD
        String sqlAlteracao = "update professor set nome=? where codigo=?";

        // Armazena a quantidade registros que foram inseridos
        int registrosAlterados=0;
        
        // Tente executar os comandos abaixo
        try {
            // Conectando ao SGBD
            conexao = DriverManager.getConnection(url, usuario, senha);

            // Preparando a exclusao que será enviada ao SGBD
            PreparedStatement stmtUpdate = conexao.prepareStatement(sqlAlteracao);

            // Atribuindo o valor do nome no primeiro parametro do update preparado acima
            stmtUpdate.setString(1, nome);

            // Atribuindo o valor do rm no segundo parametro do update preparado acima
            stmtUpdate.setString(2, codigo);
            
            // Executando a exclusao
            registrosAlterados = stmtUpdate.executeUpdate();

            // Fechando conexao com Servidor de Banco de dados
            conexao.close();
            
        } 
        
        
        // Caso os comandos acima apresentem erros, capture o erro e exiba uma janela apresentado o erro
        catch (SQLException e) {
            // Crie uma janela para exibir a mensagem de erro.
            JOptionPane.showMessageDialog(botaoConsultaProfessores, "Erro ao atualizar registro: " + e.getMessage());
        }
       
        return registrosAlterados;
        
    }    
    
    public boolean validaProfessor(String codigoProfessor, String nomeProfessor){
        boolean codigoValido=true;
        boolean nomeValido=true;
        
        if ( codigoProfessor.isBlank() || codigoProfessor.isEmpty()  ){
            codigoValido=false;
        }
        if ( ! codigoProfessor.matches("\\d+") ){
            codigoValido=false;
        }
        if ( nomeProfessor.isBlank() || nomeProfessor.isEmpty() ){
            nomeValido=false;
        } 
        return codigoValido && nomeValido;
    }
    
    
    /**
     * Creates new form JanelaConsulta
     */
    public JanelaProfessores() {
        initComponents();
        consultarProfessores();
    }
   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelaProfessores = new javax.swing.JTable();
        botaoConsultaProfessores = new javax.swing.JButton();
        botaoExcluir = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        botaoInserir = new javax.swing.JButton();
        botaoAlterar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        campoTotalProfessores = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Sistema Acadêmico");
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));

        tabelaProfessores.setAutoCreateRowSorter(true);
        tabelaProfessores.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Nome do professor"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabelaProfessores.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tabelaProfessores.setShowGrid(false);
        jScrollPane1.setViewportView(tabelaProfessores);

        botaoConsultaProfessores.setBackground(new java.awt.Color(204, 255, 255));
        botaoConsultaProfessores.setText("Consultar professores");
        botaoConsultaProfessores.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botaoConsultaProfessoresMouseClicked(evt);
            }
        });

        botaoExcluir.setBackground(new java.awt.Color(255, 102, 102));
        botaoExcluir.setText("Excluir");
        botaoExcluir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botaoExcluirMouseClicked(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Cadastro de Professores");

        botaoInserir.setBackground(new java.awt.Color(153, 255, 51));
        botaoInserir.setText("Inserir");
        botaoInserir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botaoInserirMouseClicked(evt);
            }
        });

        botaoAlterar.setBackground(new java.awt.Color(255, 255, 102));
        botaoAlterar.setText("Alterar");
        botaoAlterar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botaoAlterarMouseClicked(evt);
            }
        });

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Total de Professores:");

        campoTotalProfessores.setEditable(false);
        campoTotalProfessores.setBackground(new java.awt.Color(255, 255, 204));
        campoTotalProfessores.setFont(new java.awt.Font("Courier 10 Pitch", 1, 24)); // NOI18N
        campoTotalProfessores.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        campoTotalProfessores.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        campoTotalProfessores.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(620, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addContainerGap())
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(botaoConsultaProfessores, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 608, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(botaoExcluir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(botaoInserir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(botaoAlterar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(campoTotalProfessores)))
                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addContainerGap()))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(354, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(107, 107, 107))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jLabel1)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(botaoInserir, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(botaoAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(botaoExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 170, Short.MAX_VALUE)
                            .addComponent(campoTotalProfessores, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(botaoConsultaProfessores, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botaoConsultaProfessoresMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botaoConsultaProfessoresMouseClicked
        botaoInserir.setText("Inserir");
        botaoInserir.setBackground(Color.green);
        consultarProfessores();
    }//GEN-LAST:event_botaoConsultaProfessoresMouseClicked

    private void botaoExcluirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botaoExcluirMouseClicked

        // Obtendo o número da linha selecionada na tabela
        int linhaSelecionada;
        
        try {
            linhaSelecionada = tabelaProfessores.getSelectedRow();
            // Pegando o valor da primeira coluna (codigo) que é a coluna 0
            codigo=tabelaProfessores.getValueAt(linhaSelecionada, 0).toString();

            // Pegando o valor da segunda coluna (nome) que é a coluna 1
            nome=tabelaProfessores.getValueAt(linhaSelecionada, 1).toString();
        
            int retornoJanela;
            retornoJanela = JOptionPane.showConfirmDialog(null, "Deseja excluir o professor "+nome+" ?","Excluir professor",JOptionPane.YES_NO_OPTION);
        
            if ( retornoJanela==JOptionPane.YES_OPTION){
                // Chamando função excluirProfessor com o parâmetro codigo obtido da linha selecionada acima.
                excluirProfessor(codigo);
            }
            
            // Chamando a consulta novamente para atualizar a exibição dos dados
            consultarProfessores();
           
        }
        catch (Exception error){
            JOptionPane.showMessageDialog(rootPane, "Selecione uma linha para exclusão");
        }
        
        
    }//GEN-LAST:event_botaoExcluirMouseClicked

    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
        JanelaPrincipal janelaPrincipal = new JanelaPrincipal();
        janelaPrincipal.setVisible(true);
    }//GEN-LAST:event_formWindowClosed

    private void botaoInserirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botaoInserirMouseClicked

        // Criando objeto modelo que representará o objeto tabelaProfessores
        DefaultTableModel model = (DefaultTableModel) tabelaProfessores.getModel();

        if ( botaoInserir.getText().equals("Inserir") ) {
            
            // Inserindo nova linha na tabela 
            model.insertRow(model.getRowCount(), new Object[]{"", ""});

           
            // Selecionando a linha recentemente inserida
            tabelaProfessores.setRowSelectionInterval(model.getRowCount()-1, model.getRowCount()-1); 
           
            codigo=JOptionPane.showInputDialog("Informe o código: ");
            nome=JOptionPane.showInputDialog("Informe o nome completo: ");
 
            
            if ( validaProfessor(codigo,nome) ){
                tabelaProfessores.getModel().setValueAt(codigo, tabelaProfessores.getSelectedRow(), 0);
                tabelaProfessores.getModel().setValueAt(nome, tabelaProfessores.getSelectedRow(), 1);
                botaoInserir.setText("Salvar");
                botaoInserir.setBackground(Color.red);
            } 
            else {
                JOptionPane.showMessageDialog(rootPane, "Favor inserir dados válidos");
                consultarProfessores();
            }
        }
        else if ( botaoInserir.getText().equals("Salvar") ) {
            inserirProfessor(codigo,nome);
            botaoInserir.setText("Inserir");
            botaoInserir.setBackground(Color.green);
            consultarProfessores();
           
        }
        
    }//GEN-LAST:event_botaoInserirMouseClicked

    private void botaoAlterarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botaoAlterarMouseClicked
            
            // Se existe uma linha selecionada na tabela
            if ( tabelaProfessores.getSelectedRowCount() > 0 ) {
                // Obtendo o codigo da linha selecionada
                String codigo=(String) tabelaProfessores.getModel().getValueAt(tabelaProfessores.getSelectedRow(), 0);

                // Obtendo o novo nome digitado e armazenando na variável nome
                nome=JOptionPane.showInputDialog("Informe o novo nome completo: ");
           
                // Se os dados do professor são válidos
                if ( validaProfessor(codigo,nome) ){
                    // Alterando dados do professor selecionado
                    alterarProfessor(codigo, nome);
                    // Consultando professores novamente após alteração
                    consultarProfessores();
                } 
                // Se os dados do professores não são válidos
                else {
                    JOptionPane.showMessageDialog(rootPane, "Favor inserir dados válidos");
                    // Consultando professores novamente após alteração
                    consultarProfessores();
                }                
            }
            // Se não existe uma janela selecionada na tabela
            else {
                JOptionPane.showMessageDialog(rootPane, "Selecione uma linha para ser alterada");
            }
           
           
    }//GEN-LAST:event_botaoAlterarMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new JanelaProfessores().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botaoAlterar;
    private javax.swing.JButton botaoConsultaProfessores;
    private javax.swing.JButton botaoExcluir;
    private javax.swing.JButton botaoInserir;
    private javax.swing.JTextField campoTotalProfessores;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabelaProfessores;
    // End of variables declaration//GEN-END:variables
}
