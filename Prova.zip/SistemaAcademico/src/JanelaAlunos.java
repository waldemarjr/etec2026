import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author professor
 */
public class JanelaAlunos extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(JanelaAlunos.class.getName());

    // Usuário
    String usuario = "root";

    // Senha
    String senha = "etec123";

    // Banco de dados
    String banco = "etec";
        
    // Servidor de banco de dados
    String servidor = "127.0.0.1";

    // Endereço de conexão com Servidor de Banco de Dados
    String url = "jdbc:mysql://"+servidor+"/"+banco;
    
    // Variáveis para armazenar temporariamente um novo aluno recem inserido
    String rm;
    String nome;

    // Criando variavel que representara a conexao com o SGBD
    Connection conexao;


    private void consultarAlunos(){

        int totalAlunos=0;
        
        // Consulta que será enviada ao SGBD
        String sqlConsulta = "SELECT * from aluno";

        // Criando objeto modelo que representará o objeto tabelaAlunos
        DefaultTableModel model = (DefaultTableModel) tabelaAlunos.getModel();

        // Zerando o número de linhas da tabela
        model.setRowCount(0);
        
        // Tente executar os comandos abaixo
        try {
            // Conectando ao SGBD
            conexao = DriverManager.getConnection(url, usuario, senha);

            // Preparando a consulta que será enviada ao SGBD
            PreparedStatement stmtSelect = conexao.prepareStatement(sqlConsulta);

            // Executando a consulta
            ResultSet rs = stmtSelect.executeQuery();

            
            // Enquanto a consulta enviada enviar algum registro (linha), faça
            while (rs.next()) {
                // Pegando o valor da coluna "rm" da linha retornada e guardando na variável rm
                rm = rs.getString("rm");

                // Pegando o valor da coluna "nome" da linha retornada e guardando na variável nome
                nome = rs.getString("nome");
                
                // Adicionando na tabela os valores de rm e nome
                model.addRow(new Object[]{rm, nome});

                totalAlunos++;
            }
            
            campoTotalAlunos.setText(""+totalAlunos);
             
            // Fechando conexao com Servidor de Banco de dados
            conexao.close();

        } 
        // Caso os comandos acima apresentem erros, capture o erro e exiba uma janela apresentado o erro
        catch (SQLException e) {
            // Crie uma janela para exibir a mensagem de erro.
            JOptionPane.showMessageDialog(botaoConsultaAlunos, "Erro ao consultar o banco: " + e.getMessage());
        }
       
       
    }
    
    private int excluirAluno(String rm){

        // Exclusao que será enviada ao SGBD
        String sqlExclusao = "delete from aluno where rm = ?";

        // Armazenara a quantidade de registros excluidos e que sera retornado por esta função para quem chamou ela.
        int registrosExcluidos=0;
        
        
        // Tente executar os comandos abaixo
        try {
            // Conectando ao SGBD
            conexao = DriverManager.getConnection(url, usuario, senha);

            // Preparando a exclusao que será enviada ao SGBD
            PreparedStatement stmtDelete = conexao.prepareStatement(sqlExclusao);

            // Atribuindo o valor do rm no primeiro parametro da exclusao preparada acima
            stmtDelete.setString(1, rm);
            
            // Executando a exclusao
            registrosExcluidos = stmtDelete.executeUpdate();

            // Fechando conexao com Servidor de Banco de dados
            conexao.close();
            
        } 
        
        // Caso os comandos acima apresentem erros, capture o erro e exiba uma janela apresentado o erro
        catch (SQLException e) {
            // Crie uma janela para exibir a mensagem de erro.
            JOptionPane.showMessageDialog(botaoConsultaAlunos, "Erro ao excluir registro: " + e.getMessage());
        }
       
        return registrosExcluidos;
        
    }

    private int inserirAluno(String rm, String nome){

        // Exclusao que será enviada ao SGBD
        String sqlInsercao = "insert into aluno (rm,nome) values (?,?)";

        // Armazena a quantidade registros que foram inseridos
        int registrosInseridos=0;
        
        // Tente executar os comandos abaixo
        try {
            // Conectando ao SGBD
            conexao = DriverManager.getConnection(url, usuario, senha);

            // Preparando a exclusao que será enviada ao SGBD
            PreparedStatement stmtInsert = conexao.prepareStatement(sqlInsercao);

            // Atribuindo o valor do rm no primeiro parametro da insercao preparada acima
            stmtInsert.setString(1, rm);

            // Atribuindo o valor do nome no segundo parametro da insercao preparada acima
            stmtInsert.setString(2, nome);
            
            // Executando a exclusao
            registrosInseridos = stmtInsert.executeUpdate();

            // Fechando conexao com Servidor de Banco de dados
            conexao.close();
            
        } 
        
        
        // Caso os comandos acima apresentem erros, capture o erro e exiba uma janela apresentado o erro
        catch (SQLException error) {
            // Crie uma janela para exibir a mensagem de erro.
            if ( error.getErrorCode() == 1062 ) {
                JOptionPane.showMessageDialog(botaoConsultaAlunos, "RM já cadastrado");
            }
            else {
                JOptionPane.showMessageDialog(botaoConsultaAlunos, "Erro ao inserir registro: " + error.getMessage());
            }
            
        }
       
        return registrosInseridos;
        
    }    

    private int alterarAluno(String rm,  String nome){

        // Exclusao que será enviada ao SGBD
        String sqlAlteracao = "update aluno set nome=? where rm=?";

        // Armazena a quantidade registros que foram inseridos
        int registrosAlterados=0;
        
        // Tente executar os comandos abaixo
        try {
            // Conectando ao SGBD
            conexao = DriverManager.getConnection(url, usuario, senha);

            // Preparando a exclusao que será enviada ao SGBD
            PreparedStatement stmtUpdate = conexao.prepareStatement(sqlAlteracao);

            // Atribuindo o valor do nome no primeiro parametro do update preparado acima
            stmtUpdate.setString(1, nome);

            // Atribuindo o valor do rm no segundo parametro do update preparado acima
            stmtUpdate.setString(2, rm);
            
            // Executando a exclusao
            registrosAlterados = stmtUpdate.executeUpdate();

            // Fechando conexao com Servidor de Banco de dados
            conexao.close();
            
        } 
        
        
        // Caso os comandos acima apresentem erros, capture o erro e exiba uma janela apresentado o erro
        catch (SQLException e) {
            // Crie uma janela para exibir a mensagem de erro.
            JOptionPane.showMessageDialog(botaoConsultaAlunos, "Erro ao atualizar registro: " + e.getMessage());
        }
       
        return registrosAlterados;
        
    }    
    
    public boolean validaAluno(String rmAluno, String nomeAluno){
        boolean rmValido=true;
        boolean nomeValido=true;
        
        if ( rmAluno.isBlank() || rmAluno.isEmpty()  ){
            rmValido=false;
        }
        if ( ! rmAluno.matches("\\d+") ){
            rmValido=false;
        }
        if ( nomeAluno.isBlank() || nomeAluno.isEmpty() ){
            nomeValido=false;
        } 
        return rmValido && nomeValido;
    }
    
    
    /**
     * Creates new form JanelaConsulta
     */
    public JanelaAlunos() {
        initComponents();
        consultarAlunos();
    }
   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelaAlunos = new javax.swing.JTable();
        botaoConsultaAlunos = new javax.swing.JButton();
        botaoExcluir = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        botaoInserir = new javax.swing.JButton();
        botaoAlterar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        campoTotalAlunos = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Sistema Acadêmico");
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));

        tabelaAlunos.setAutoCreateRowSorter(true);
        tabelaAlunos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "RM", "Nome do aluno"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabelaAlunos.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tabelaAlunos.setShowGrid(false);
        jScrollPane1.setViewportView(tabelaAlunos);

        botaoConsultaAlunos.setBackground(new java.awt.Color(204, 255, 255));
        botaoConsultaAlunos.setText("Consultar alunos");
        botaoConsultaAlunos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botaoConsultaAlunosMouseClicked(evt);
            }
        });

        botaoExcluir.setBackground(new java.awt.Color(255, 102, 102));
        botaoExcluir.setText("Excluir");
        botaoExcluir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botaoExcluirMouseClicked(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Cadastro de Alunos");

        botaoInserir.setBackground(new java.awt.Color(153, 255, 51));
        botaoInserir.setText("Inserir");
        botaoInserir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botaoInserirMouseClicked(evt);
            }
        });

        botaoAlterar.setBackground(new java.awt.Color(255, 255, 102));
        botaoAlterar.setText("Alterar");
        botaoAlterar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botaoAlterarMouseClicked(evt);
            }
        });

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Total de Alunos:");

        campoTotalAlunos.setEditable(false);
        campoTotalAlunos.setBackground(new java.awt.Color(255, 255, 204));
        campoTotalAlunos.setFont(new java.awt.Font("Courier 10 Pitch", 1, 24)); // NOI18N
        campoTotalAlunos.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        campoTotalAlunos.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        campoTotalAlunos.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(620, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(45, 45, 45))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(botaoConsultaAlunos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 608, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(botaoExcluir, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                                .addComponent(botaoInserir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(botaoAlterar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(campoTotalAlunos)))
                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addContainerGap()))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(335, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(107, 107, 107))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jLabel1)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(botaoInserir, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(botaoAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(botaoExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 151, Short.MAX_VALUE)
                            .addComponent(campoTotalAlunos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(botaoConsultaAlunos, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botaoConsultaAlunosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botaoConsultaAlunosMouseClicked
        botaoInserir.setText("Inserir");
        botaoInserir.setBackground(Color.green);
        consultarAlunos();
    }//GEN-LAST:event_botaoConsultaAlunosMouseClicked

    private void botaoExcluirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botaoExcluirMouseClicked

        // Obtendo o número da linha selecionada na tabela
        int linhaSelecionada;
        
        try {
            linhaSelecionada = tabelaAlunos.getSelectedRow();
            // Pegando o valor da primeira coluna (rm) que é a coluna 0
            rm=tabelaAlunos.getValueAt(linhaSelecionada, 0).toString();

            // Pegando o valor da segunda coluna (nome) que é a coluna 1
            nome=tabelaAlunos.getValueAt(linhaSelecionada, 1).toString();
        
            int retornoJanela;
            retornoJanela = JOptionPane.showConfirmDialog(null, "Deseja excluir o aluno "+nome+" ?","Excluir aluno",JOptionPane.YES_NO_OPTION);
        
            if ( retornoJanela==JOptionPane.YES_OPTION){
                // Chamando função excluirAluno com o parâmetro rm obtido da linha selecionada acima.
                excluirAluno(rm);
            }
            
            // Chamando a consulta novamente para atualizar a exibição dos dados
            consultarAlunos();
           
        }
        catch (Exception error){
            JOptionPane.showMessageDialog(rootPane, "Selecione uma linha para exclusão");
        }
        
        
    }//GEN-LAST:event_botaoExcluirMouseClicked

    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
        JanelaPrincipal janelaPrincipal = new JanelaPrincipal();
        janelaPrincipal.setVisible(true);
    }//GEN-LAST:event_formWindowClosed

    private void botaoInserirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botaoInserirMouseClicked

        // Criando objeto modelo que representará o objeto tabelaAlunos
        DefaultTableModel model = (DefaultTableModel) tabelaAlunos.getModel();

        if ( botaoInserir.getText().equals("Inserir") ) {
            
            // Inserindo nova linha na tabela 
            model.insertRow(model.getRowCount(), new Object[]{"", ""});

           
            // Selecionando a linha recentemente inserida
            tabelaAlunos.setRowSelectionInterval(model.getRowCount()-1, model.getRowCount()-1); 
           
            rm=JOptionPane.showInputDialog("Informe o RM: ");
            nome=JOptionPane.showInputDialog("Informe o nome completo: ");
 
            
            if ( validaAluno(rm,nome) ){
                tabelaAlunos.getModel().setValueAt(rm, tabelaAlunos.getSelectedRow(), 0);
                tabelaAlunos.getModel().setValueAt(nome, tabelaAlunos.getSelectedRow(), 1);
                botaoInserir.setText("Salvar");
                botaoInserir.setBackground(Color.red);
            } 
            else {
                JOptionPane.showMessageDialog(rootPane, "Favor inserir dados válidos");
                consultarAlunos();
            }
        }
        else if ( botaoInserir.getText().equals("Salvar") ) {
            inserirAluno(rm,nome);
            botaoInserir.setText("Inserir");
            botaoInserir.setBackground(Color.green);
            consultarAlunos();
           
        }
        
    }//GEN-LAST:event_botaoInserirMouseClicked

    private void botaoAlterarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botaoAlterarMouseClicked
            
            // Se existe uma linha selecionada na tabela
            if ( tabelaAlunos.getSelectedRowCount() > 0 ) {
                // Obtendo o rm da linha selecionada
                String rm=(String) tabelaAlunos.getModel().getValueAt(tabelaAlunos.getSelectedRow(), 0);

                // Obtendo o novo nome digitado e armazenando na variável nome
                nome=JOptionPane.showInputDialog("Informe o novo nome completo: ");
           
                // Se os dados do aluno são válidos
                if ( validaAluno(rm,nome) ){
                    // Alterando dados do aluno selecionado
                    alterarAluno(rm, nome);
                    // Consultando alunos novamente após alteração
                    consultarAlunos();
                } 
                // Se os dados do aluno não são válidos
                else {
                    JOptionPane.showMessageDialog(rootPane, "Favor inserir dados válidos");
                    // Consultando alunos novamente após alteração
                    consultarAlunos();
                }                
            }
            // Se não existe uma janela selecionada na tabela
            else {
                JOptionPane.showMessageDialog(rootPane, "Selecione uma linha para ser alterada");
            }
           
           
    }//GEN-LAST:event_botaoAlterarMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new JanelaAlunos().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botaoAlterar;
    private javax.swing.JButton botaoConsultaAlunos;
    private javax.swing.JButton botaoExcluir;
    private javax.swing.JButton botaoInserir;
    private javax.swing.JTextField campoTotalAlunos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabelaAlunos;
    // End of variables declaration//GEN-END:variables
}
