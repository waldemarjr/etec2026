import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.table.DefaultTableModel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author professor
 */
public class JanelaUsuarios extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(JanelaProfessores.class.getName());

    // Usuário
    String usuario = "root";

    // Senha
    String senha = "etec123";

    // Banco de dados
    String banco = "etec";
        
    // Servidor de banco de dados
    String servidor = "127.0.0.1";

    // Endereço de conexão com Servidor de Banco de Dados
    String url = "jdbc:mysql://"+servidor+"/"+banco;
    
    // Variáveis para armazenar temporariamente um novo usuario recem inserido
    String codigoUsuario;
    String nomeUsuario;
    String senhaUsuario;
    String senhaConfirmUsuario;

    // Variáveis para armazenar temporariamente informacoes de auditoria do usuario selecionado
    String enderecoIP;
    String dataHora;
    String tipoEvento;
    
    String statusUsuario;
    String papelUsuario;
    
    // Criando variavel que representara a conexao com o SGBD
    Connection conexao;

    private void consultarInfoUsuario(String nomeUsuario){
   
        
        // Consulta que será enviada ao SGBD
        String sqlConsulta = "SELECT * from auditoria where usuario = ? order by data_hora desc";

        // Criando objeto modelo que representará o objeto tabelaAuditoria
        DefaultTableModel model = (DefaultTableModel) tabelaAuditoria.getModel();

        // Zerando o número de linhas da tabela
        model.setRowCount(0);
        
        // Tente executar os comandos abaixo
        try {
            // Conectando ao SGBD
            conexao = DriverManager.getConnection(url, usuario, senha);

            // Preparando a consulta que será enviada ao SGBD
            PreparedStatement stmtSelect = conexao.prepareStatement(sqlConsulta);

            // Inserindo valor obtido (nomeUsuario na consulta que foi preparada acimna)
            stmtSelect.setString(1, nomeUsuario);
           
            // Executando a consulta
            ResultSet rs = stmtSelect.executeQuery();
            
            // Enquanto a consulta enviada enviar algum registro (linha), faça
            while (rs.next()) {
                
                // Pegando o valor da coluna "endereco_ip" da linha retornada e guardando na variável enderecoIP
                enderecoIP = rs.getString("endereco_ip");

                // Pegando o valor da coluna "data_hora" da linha retornada e guardando na variável dataHora
                dataHora = rs.getString("data_hora");

                // Pegando o valor da coluna "tipo_evento" da linha retornada e guardando na variável tipoEvento
                tipoEvento = rs.getString("tipo_evento");

                // Adicionando na tabela os valores de codigoUsuario e nomeUsuario
                model.addRow(new Object[]{enderecoIP,dataHora,tipoEvento});
                
            }
            
            // Fechando conexao com Servidor de Banco de dados
            conexao.close();

        } 
        // Caso os comandos acima apresentem erros, capture o erro e exiba uma janela apresentado o erro
        catch (SQLException e) {
            // Crie uma janela para exibir a mensagem de erro.
            JOptionPane.showMessageDialog(rootPane, "Erro ao consultar o banco: " + e.getMessage());
        }
       
       
    }
    
    
    
    
    private void consultarUsuarios(){
        int totalUsuarios=0;
        
        // Consulta que será enviada ao SGBD
        String sqlConsulta = "select u.codigo as codigo_usuario,nome,status, p.nome_papel as papel_usuario from usuario u, papeis p where u.codigo_papel=p.codigo;";
        
        // Criando objeto modelo que representará o objeto tabelaProfessores
        DefaultTableModel model = (DefaultTableModel) tabelaUsuarios.getModel();

        // Zerando o número de linhas da tabela
        model.setRowCount(0);
        
        // Tente executar os comandos abaixo
        try {
            // Conectando ao SGBD
            conexao = DriverManager.getConnection(url, usuario, senha);

            // Preparando a consulta que será enviada ao SGBD
            PreparedStatement stmtSelect = conexao.prepareStatement(sqlConsulta);

            // Executando a consulta
            ResultSet rs = stmtSelect.executeQuery();

            
            // Enquanto a consulta enviada enviar algum registro (linha), faça
            while (rs.next()) {
                // Pegando o valor da coluna "codigo_usuario" da linha retornada e guardando na variável rm
                codigoUsuario = rs.getString("codigo_usuario");

                // Pegando o valor da coluna "nome" da linha retornada e guardando na variável nome
                nomeUsuario = rs.getString("nome");
                
                // Pegando o valor da coluna "status" da linha retornada e guardando na variável statusUsuario
                statusUsuario = rs.getString("status");
                
                // Pegando o valor da coluna "papel_usuario" da linha retornada e guardando na variável statusUsuario
                papelUsuario = rs.getString("papel_usuario");

                // Adicionando na tabela os valores de codigoUsuario e nomeUsuario
                model.addRow(new Object[]{codigoUsuario, nomeUsuario,statusUsuario,papelUsuario});

                totalUsuarios++;
            }
            
            campoTotalUsuarios.setText(""+totalUsuarios);
             
            // Fechando conexao com Servidor de Banco de dados
            conexao.close();

        } 
        // Caso os comandos acima apresentem erros, capture o erro e exiba uma janela apresentado o erro
        catch (SQLException e) {
            // Crie uma janela para exibir a mensagem de erro.
            JOptionPane.showMessageDialog(botaoConsultaUsuarios, "Erro ao consultar o banco: " + e.getMessage());
        }
       
       
    }
    
    
    private void consultarPapeis(JComboBox combo){
        
        String codigoPapel;
        String nomePapel;
        int contadorPapeis=0;
        
        // Consulta que será enviada ao SGBD
        String sqlConsulta = "select codigo,nome_papel from papeis";
        
       
        // Tente executar os comandos abaixo
        try {
            // Conectando ao SGBD
            conexao = DriverManager.getConnection(url, usuario, senha);

            // Preparando a consulta que será enviada ao SGBD
            PreparedStatement stmtSelect = conexao.prepareStatement(sqlConsulta);

            // Executando a consulta
            ResultSet rs = stmtSelect.executeQuery();

            // Removendo papeis do combobox
            combo.removeAllItems();
            
            // Enquanto a consulta enviada enviar algum registro (linha), faça
            while (rs.next()) {
                // Pegando o valor da coluna "codigo" da linha retornada e guardando na variável codigoPapel
                codigoPapel = rs.getString("codigo");

                // Pegando o valor da coluna "nome_papel" da linha retornada e guardando na variável nomePapel
                nomePapel = rs.getString("nome_papel");
                
                combo.addItem(codigoPapel+"-"+nomePapel);

                contadorPapeis++;
            }
            
            if ( contadorPapeis == 0 ){
                combo.addItem("Não existem papéis cadastrados");
                combo.disable();
            }
            
            // Fechando conexao com Servidor de Banco de dados
            conexao.close();

        } 
        // Caso os comandos acima apresentem erros, capture o erro e exiba uma janela apresentado o erro
        catch (SQLException e) {
            // Crie uma janela para exibir a mensagem de erro.
            JOptionPane.showMessageDialog(rootPane, "Erro ao consultar o banco: " + e.getMessage());
        }
       
       
    }
    
    
   
    private int excluirUsuario(String codigoUsuario){

        
        // Exclusao que será enviada ao SGBD
        String sqlExclusao = "delete from usuario where codigo = ?";

        // Armazenara a quantidade de registros excluidos e que sera retornado por esta função para quem chamou ela.
        int registrosExcluidos=0;
        
        
        // Tente executar os comandos abaixo
        try {
            // Conectando ao SGBD
            conexao = DriverManager.getConnection(url, usuario, senha);

            // Preparando a exclusao que será enviada ao SGBD
            PreparedStatement stmtDelete = conexao.prepareStatement(sqlExclusao);

            // Atribuindo o valor do rm no primeiro parametro da exclusao preparada acima
            stmtDelete.setString(1, codigoUsuario);
            
            // Executando a exclusao
            registrosExcluidos = stmtDelete.executeUpdate();

            // Fechando conexao com Servidor de Banco de dados
            conexao.close();
            
        } 
        
        // Caso os comandos acima apresentem erros, capture o erro e exiba uma janela apresentado o erro
        catch (SQLException e) {
            // Crie uma janela para exibir a mensagem de erro.
            JOptionPane.showMessageDialog(botaoConsultaUsuarios, "Erro ao excluir registro: " + e.getMessage());
        }
       
        return registrosExcluidos;
        
    }

    private int inserirUsuario(String codigoUsuario, String nomeUsuario, String senhaUsuario){

        // Exclusao que será enviada ao SGBD
        String sqlInsercao = "insert into usuario (codigo,nome,senha,status) values (?,?,md5(?),?)";

        // Armazena a quantidade registros que foram inseridos
        int registrosInseridos=0;
        
        // Tente executar os comandos abaixo
        try {
            // Conectando ao SGBD
            conexao = DriverManager.getConnection(url, usuario, senha);

            // Preparando a exclusao que será enviada ao SGBD
            PreparedStatement stmtInsert = conexao.prepareStatement(sqlInsercao);

            // Atribuindo o valor do codigo no primeiro parametro da insercao preparada acima
            stmtInsert.setString(1, codigoUsuario);

            // Atribuindo o valor do nome no segundo parametro da insercao preparada acima
            stmtInsert.setString(2, nomeUsuario);

            // Atribuindo o valor da senha no terceiro parametro da insercao preparada acima
            stmtInsert.setString(3, senhaUsuario);

            // Atribuindo o valor do status no quarto parametro da insercao preparada acima
            stmtInsert.setString(4, "desbloqueado");

            
            // Executando a exclusao
            registrosInseridos = stmtInsert.executeUpdate();

            // Fechando conexao com Servidor de Banco de dados
            conexao.close();
            
        } 
        
        
        // Caso os comandos acima apresentem erros, capture o erro e exiba uma janela apresentado o erro
        catch (SQLException error) {
            // Crie uma janela para exibir a mensagem de erro.
            if ( error.getErrorCode() == 1062 ) {
                JOptionPane.showMessageDialog(botaoConsultaUsuarios, "Código já cadastrado");
            }
            else {
                JOptionPane.showMessageDialog(botaoConsultaUsuarios, "Erro ao inserir registro: " + error.getMessage());
            }
            
        }
       
        return registrosInseridos;
        
    }    

    private boolean alterarPapelUsuario(String codigoUsuario, String codigoPapelUsuario) {

        
        // Tente executar os comandos abaixo
        try {
            // Conectando ao SGBD
            conexao = DriverManager.getConnection(url, usuario, senha);


            if ( ! codigoUsuario.isEmpty() && !papelUsuario.isEmpty() ){
                // Exclusao que será enviada ao SGBD
                String sqlAlteracao = "update usuario set codigo_papel=? where codigo=?";

                // Preparando a exclusao que será enviada ao SGBD
                PreparedStatement stmtUpdate = conexao.prepareStatement(sqlAlteracao);

                // Atribuindo o valor do nome no primeiro parametro do update preparado acima
                stmtUpdate.setString(1, codigoPapelUsuario);

                // Atribuindo o valor do codigo no segundo parametro do update preparado acima
                stmtUpdate.setString(2, codigoUsuario);

                // Executando a alteração
                stmtUpdate.executeUpdate();
                           
            }

            // Fechando conexao com Servidor de Banco de dados
            conexao.close();
            
        } 
        
        // Caso os comandos acima apresentem erros, capture o erro e exiba uma janela apresentado o erro
        catch (SQLException e) {
            // Crie uma janela para exibir a mensagem de erro.
            JOptionPane.showMessageDialog(botaoConsultaUsuarios, "Erro ao atualizar registro: " + e.getMessage());
            return false;
        }
       
        return true;
        
     }

     private int alterarNomeUsuario(String codigoUsuario,  String nomeUsuario){

        // Armazena a quantidade registros que foram inseridos
        int registrosAlterados=0;
        
        // Tente executar os comandos abaixo
        try {
            // Conectando ao SGBD
            conexao = DriverManager.getConnection(url, usuario, senha);


            if ( ! codigoUsuario.isEmpty() && !nomeUsuario.isEmpty() ){
                // Exclusao que será enviada ao SGBD
                String sqlAlteracao = "update usuario set nome=? where codigo=?";

                // Preparando a exclusao que será enviada ao SGBD
                PreparedStatement stmtUpdate = conexao.prepareStatement(sqlAlteracao);

                // Atribuindo o valor do nome no primeiro parametro do update preparado acima
                stmtUpdate.setString(1, nomeUsuario);

                // Atribuindo o valor do codigo no segundo parametro do update preparado acima
                stmtUpdate.setString(2, codigoUsuario);

                // Executando a alteração
                registrosAlterados = stmtUpdate.executeUpdate();
                           
            }

            // Fechando conexao com Servidor de Banco de dados
            conexao.close();
            
        } 
        
        
        // Caso os comandos acima apresentem erros, capture o erro e exiba uma janela apresentado o erro
        catch (SQLException e) {
            // Crie uma janela para exibir a mensagem de erro.
            JOptionPane.showMessageDialog(botaoConsultaUsuarios, "Erro ao atualizar registro: " + e.getMessage());
        }
       
        return registrosAlterados;
        
    }    
    

    private int alterarSenhaUsuario(String codigoUsuario,  String senhaUsuario){

        // Armazena a quantidade registros que foram inseridos
        int registrosAlterados=0;
        
        // Tente executar os comandos abaixo
        try {
            // Conectando ao SGBD
            conexao = DriverManager.getConnection(url, usuario, senha);


            if ( ! codigoUsuario.isEmpty() && !senhaUsuario.isEmpty() ){
                // Exclusao que será enviada ao SGBD
                String sqlAlteracao = "update usuario set senha=md5(?) where codigo=?";

                // Preparando a exclusao que será enviada ao SGBD
                PreparedStatement stmtUpdate = conexao.prepareStatement(sqlAlteracao);

                // Atribuindo o valor da senha no primeiro parametro do update preparado acima
                stmtUpdate.setString(1, senhaUsuario);

                // Atribuindo o valor do codigo no segundo parametro do update preparado acima
                stmtUpdate.setString(2, codigoUsuario);

                // Executando a alteração
                registrosAlterados = stmtUpdate.executeUpdate();
                           
            }

            // Fechando conexao com Servidor de Banco de dados
            conexao.close();
            
        } 
        
        
        // Caso os comandos acima apresentem erros, capture o erro e exiba uma janela apresentado o erro
        catch (SQLException e) {
            // Crie uma janela para exibir a mensagem de erro.
            JOptionPane.showMessageDialog(botaoConsultaUsuarios, "Erro ao atualizar registro: " + e.getMessage());
        }
       
        return registrosAlterados;
        
    }    

    private boolean bloquearDesbloquearUsuario(String codigoUsuario,String statusAtual){
        
        // Tente executar os comandos abaixo
        try {
            // Conectando ao SGBD
            conexao = DriverManager.getConnection(url, usuario, senha);
            // Alteração que será enviada ao SGBD
            String sqlAlteracao = "update usuario set status=? where codigo=?";

            // Preparando a alteração que será enviada ao SGBD
            PreparedStatement stmtUpdate = conexao.prepareStatement(sqlAlteracao);

            // Se o status atual é bloqueado, então desbloquei o usuário
            if ( statusAtual.equals("bloqueado") ){
               // Atribuindo o valor do nome no primeiro parametro do update preparado acima
               stmtUpdate.setString(1, "desbloqueado");
            }
            // Se o status atual é desbloqueado, então bloquei o usuário
            else if ( statusAtual.equals("desbloqueado") ){
               // Atribuindo o valor do nome no primeiro parametro do update preparado acima
               stmtUpdate.setString(1, "bloqueado");
            }
   
            // Atribuindo o valor do codigo no segundo parametro do update preparado acima
            stmtUpdate.setString(2, codigoUsuario);
               
            // Executando a alteração
            stmtUpdate.executeUpdate();
   
            // Fechando conexao com Servidor de Banco de dados
            conexao.close();
            return true;
        } 
        // Caso os comandos acima apresentem erros, capture o erro e exiba uma janela apresentado o erro
        catch (SQLException e) {
            // Crie uma janela para exibir a mensagem de erro.
            JOptionPane.showMessageDialog(rootPane, "Erro ao atualizar registro: " + e.getMessage());
        }
       
        return false;
        
    }
    
    
   
    public boolean validaNomeUsuario(String codigoUsuario, String nomeUsuario){
        boolean codigoValido=true;
        boolean nomeValido=true;
        
        if ( codigoUsuario.isBlank() || codigoUsuario.isEmpty() ){
            codigoValido=false;
        }
        if ( ! codigoUsuario.matches("\\d+") ){
            codigoValido=false;
        }
        if ( nomeUsuario.isBlank() || nomeUsuario.isEmpty() ){
            nomeValido=false;
        } 
              
        return codigoValido && nomeValido;
    }
    
    public boolean validaSenhaUsuario(String senhaUsuario, String senhaConfirmUsuario){
        
        if ( senhaUsuario.equals(senhaConfirmUsuario) ){
            return true;
        } else {
            return false;
        }
        
    }
    
    
    /**
     * Creates new form JanelaConsulta
     */
    public JanelaUsuarios() {
        initComponents();
        // Ocultando botão de bloquear/desbloquear usuários
        botaoBloquearDesbloquear.setVisible(false);
        // Consultando usuários
        consultarUsuarios();
    }
   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelaUsuarios = new javax.swing.JTable();
        botaoConsultaUsuarios = new javax.swing.JButton();
        botaoExcluir = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        botaoInserir = new javax.swing.JButton();
        botaoAlterarNome = new javax.swing.JButton();
        botaoBloquearDesbloquear = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        campoTotalUsuarios = new javax.swing.JTextField();
        botaoAlterarSenha = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabelaAuditoria = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        comboPapeis = new javax.swing.JComboBox<>();
        botaoAlterarPapel = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Sistema Acadêmico");
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));

        tabelaUsuarios.setAutoCreateRowSorter(true);
        tabelaUsuarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Nome do usuário", "Status", "Papel"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabelaUsuarios.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tabelaUsuarios.setShowGrid(false);
        tabelaUsuarios.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelaUsuariosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabelaUsuarios);
        if (tabelaUsuarios.getColumnModel().getColumnCount() > 0) {
            tabelaUsuarios.getColumnModel().getColumn(0).setResizable(false);
            tabelaUsuarios.getColumnModel().getColumn(1).setResizable(false);
            tabelaUsuarios.getColumnModel().getColumn(2).setResizable(false);
            tabelaUsuarios.getColumnModel().getColumn(3).setResizable(false);
        }

        botaoConsultaUsuarios.setBackground(new java.awt.Color(204, 255, 255));
        botaoConsultaUsuarios.setText("Consultar Usuários");
        botaoConsultaUsuarios.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botaoConsultaUsuariosMouseClicked(evt);
            }
        });

        botaoExcluir.setBackground(new java.awt.Color(255, 102, 102));
        botaoExcluir.setText("Excluir");
        botaoExcluir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botaoExcluirMouseClicked(evt);
            }
        });

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Cadastro de Usuários");

        botaoInserir.setBackground(new java.awt.Color(153, 255, 51));
        botaoInserir.setText("Inserir");
        botaoInserir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botaoInserirMouseClicked(evt);
            }
        });

        botaoAlterarNome.setBackground(new java.awt.Color(255, 255, 102));
        botaoAlterarNome.setText("Renomear");
        botaoAlterarNome.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botaoAlterarNomeMouseClicked(evt);
            }
        });

        botaoBloquearDesbloquear.setBackground(java.awt.Color.red);
        botaoBloquearDesbloquear.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botaoBloquearDesbloquearMouseClicked(evt);
            }
        });

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Total de Usuários:");

        campoTotalUsuarios.setEditable(false);
        campoTotalUsuarios.setBackground(new java.awt.Color(255, 255, 204));
        campoTotalUsuarios.setFont(new java.awt.Font("Courier 10 Pitch", 1, 24)); // NOI18N
        campoTotalUsuarios.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        campoTotalUsuarios.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        campoTotalUsuarios.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        botaoAlterarSenha.setBackground(new java.awt.Color(153, 255, 255));
        botaoAlterarSenha.setText("Alterar senha");
        botaoAlterarSenha.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botaoAlterarSenhaMouseClicked(evt);
            }
        });

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Informações de auditoria do usuário:");

        tabelaAuditoria.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Endereço IP", "Data e hora", "Tipo de evento"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(tabelaAuditoria);
        if (tabelaAuditoria.getColumnModel().getColumnCount() > 0) {
            tabelaAuditoria.getColumnModel().getColumn(0).setResizable(false);
            tabelaAuditoria.getColumnModel().getColumn(1).setResizable(false);
            tabelaAuditoria.getColumnModel().getColumn(2).setResizable(false);
        }

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Papel do usuário:");

        consultarPapeis(comboPapeis);

        botaoAlterarPapel.setText("Alterar papel do usuário");
        botaoAlterarPapel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botaoAlterarPapelMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(comboPapeis, javax.swing.GroupLayout.PREFERRED_SIZE, 412, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addComponent(botaoAlterarPapel)
                                        .addGap(190, 190, 190))
                                    .addComponent(botaoExcluir, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(botaoAlterarSenha, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(botaoInserir, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(botaoAlterarNome, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(botaoBloquearDesbloquear, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(campoTotalUsuarios, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 640, Short.MAX_VALUE)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 640, Short.MAX_VALUE)
                                .addComponent(botaoConsultaUsuarios, javax.swing.GroupLayout.DEFAULT_SIZE, 640, Short.MAX_VALUE))
                            .addGap(188, 188, 188)))
                    .addContainerGap()))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addComponent(botaoInserir, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 212, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(comboPapeis, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(botaoAlterarPapel))
                        .addGap(10, 10, 10)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(campoTotalUsuarios, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3)
                        .addGap(224, 224, 224))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(botaoAlterarNome, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(botaoAlterarSenha, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(botaoExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(botaoBloquearDesbloquear, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jLabel1)
                    .addGap(12, 12, 12)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 59, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(botaoConsultaUsuarios, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botaoConsultaUsuariosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botaoConsultaUsuariosMouseClicked
        botaoInserir.setText("Inserir");
        botaoInserir.setBackground(Color.green);
        consultarUsuarios();
    }//GEN-LAST:event_botaoConsultaUsuariosMouseClicked

    private void botaoExcluirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botaoExcluirMouseClicked

        if ( ! JanelaLogin.papelUsuario.equals("Administrador") ) {
            JOptionPane.showMessageDialog(rootPane, "Ação autorizada somente para administradores");
        }
        else {
            // Obtendo o número da linha selecionada na tabela
            int linhaSelecionada;
        
            try {
                linhaSelecionada = tabelaUsuarios.getSelectedRow();
                // Pegando o valor da primeira coluna (codigo) que é a coluna 0
                codigoUsuario=tabelaUsuarios.getValueAt(linhaSelecionada, 0).toString();

                // Pegando o valor da segunda coluna (nome) que é a coluna 1
                nomeUsuario=tabelaUsuarios.getValueAt(linhaSelecionada, 1).toString();
        
                int retornoJanela;
                retornoJanela = JOptionPane.showConfirmDialog(null, "Deseja excluir o usuário "+nomeUsuario+" ?","Excluir usuário",JOptionPane.YES_NO_OPTION);
        
                if ( retornoJanela==JOptionPane.YES_OPTION){
                    // Chamando função excluirAluno com o parâmetro codigo obtido da linha selecionada acima.
                    excluirUsuario(codigoUsuario);
                }
            
                // Chamando a consulta novamente para atualizar a exibição dos dados
                consultarUsuarios();
           
            }
            catch (Exception error){
                JOptionPane.showMessageDialog(rootPane, "Selecione uma linha para exclusão");
            }
        }
        
    }//GEN-LAST:event_botaoExcluirMouseClicked

    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
        JanelaPrincipal janelaPrincipal = new JanelaPrincipal();
        janelaPrincipal.setVisible(true);
    }//GEN-LAST:event_formWindowClosed

    private void botaoInserirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botaoInserirMouseClicked
        if ( ! JanelaLogin.papelUsuario.equals("Administrador") ) {
            JOptionPane.showMessageDialog(rootPane, "Ação autorizada somente para administradores");
        }
        else {
        
            // Criando objeto modelo que representará o objeto tabelaProfessores
            DefaultTableModel model = (DefaultTableModel) tabelaUsuarios.getModel();

            if ( botaoInserir.getText().equals("Inserir") ) {
            
                // Inserindo nova linha na tabela 
                model.insertRow(model.getRowCount(), new Object[]{"", ""});

           
                // Selecionando a linha recentemente inserida
                tabelaUsuarios.setRowSelectionInterval(model.getRowCount()-1, model.getRowCount()-1); 
           
                codigoUsuario=JOptionPane.showInputDialog("Informe o código do usuário: ");
                nomeUsuario=JOptionPane.showInputDialog("Informe o nome do usuário ");
            
                JPasswordField campoSenha = new JPasswordField();
                campoSenha.setEchoChar('*');

                JOptionPane.showConfirmDialog(null,campoSenha,"Senha do usuário",JOptionPane.OK_CANCEL_OPTION);
                senhaUsuario=new String(campoSenha.getPassword());

                JPasswordField campoSenhaConfirm = new JPasswordField();
                campoSenhaConfirm.setEchoChar('*');

                JOptionPane.showConfirmDialog(null,campoSenhaConfirm,"Confirmação da senha",JOptionPane.OK_CANCEL_OPTION);
                senhaConfirmUsuario=new String(campoSenhaConfirm.getPassword());
            
     
                if ( ! validaSenhaUsuario(senhaUsuario,senhaConfirmUsuario) ){
                    JOptionPane.showMessageDialog(rootPane, "Favor inserir senhas iguais");
                }
                else {
                    if ( validaNomeUsuario(codigoUsuario,nomeUsuario) && validaSenhaUsuario(senhaUsuario,senhaConfirmUsuario)){
                        tabelaUsuarios.getModel().setValueAt(codigoUsuario, tabelaUsuarios.getSelectedRow(), 0);
                        tabelaUsuarios.getModel().setValueAt(nomeUsuario, tabelaUsuarios.getSelectedRow(), 1);
                        botaoInserir.setText("Salvar");
                        botaoInserir.setBackground(Color.red);
                    } 
                    else {
                        JOptionPane.showMessageDialog(rootPane, "Favor inserir dados válidos");
                        consultarUsuarios();
                    }
                }
            }
            else if ( botaoInserir.getText().equals("Salvar") ) {
                inserirUsuario(codigoUsuario,nomeUsuario,senhaUsuario);
                botaoInserir.setText("Inserir");
                botaoInserir.setBackground(Color.green);
                consultarUsuarios();
            }
        }
    }//GEN-LAST:event_botaoInserirMouseClicked

    private void botaoAlterarNomeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botaoAlterarNomeMouseClicked

        if ( ! JanelaLogin.papelUsuario.equals("Administrador") ) {
            JOptionPane.showMessageDialog(rootPane, "Ação autorizada somente para administradores"); 
        }
        else {
        
            // Se existe uma linha selecionada na tabela
            if ( tabelaUsuarios.getSelectedRowCount() > 0 ) {
                // Obtendo o codigo da linha selecionada
                codigoUsuario=(String) tabelaUsuarios.getModel().getValueAt(tabelaUsuarios.getSelectedRow(), 0);

                // Obtendo o novo nome digitado e armazenando na variável nome
                nomeUsuario=JOptionPane.showInputDialog("Informe o novo de usuário: ");

                
                // Se os dados do usuário são válidos
                if ( validaNomeUsuario(codigoUsuario,nomeUsuario) ){
                    // Alterando dados do usuário selecionado
                    alterarNomeUsuario(codigoUsuario, nomeUsuario);
                    // Consultando usuários novamente após alteração
                    consultarUsuarios();
                } 
                // Se os dados do aluno não são válidos
                else {
                    JOptionPane.showMessageDialog(rootPane, "Favor inserir dados válidos");
                    // Consultando cursos novamente após alteração
                    consultarUsuarios();
                }                
            }
            // Se não existe uma linha selecionada na tabela
            else {
                JOptionPane.showMessageDialog(rootPane, "Selecione uma linha para ser alterada");
            }
        }   
           
    }//GEN-LAST:event_botaoAlterarNomeMouseClicked

    private void botaoAlterarSenhaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botaoAlterarSenhaMouseClicked

        if ( ! JanelaLogin.papelUsuario.equals("Administrador") ) {
            JOptionPane.showMessageDialog(rootPane, "Ação autorizada somente para administradores");
        }
        else {
            // Se existe uma linha selecionada na tabela
            if ( tabelaUsuarios.getSelectedRowCount() > 0 ) {
                // Obtendo o codigo da linha selecionada
                codigoUsuario=(String) tabelaUsuarios.getModel().getValueAt(tabelaUsuarios.getSelectedRow(), 0);

                JPasswordField campoSenha = new JPasswordField();
                campoSenha.setEchoChar('*');

                JOptionPane.showConfirmDialog(null,campoSenha,"Senha do usuário",JOptionPane.OK_CANCEL_OPTION);
                senhaUsuario=new String(campoSenha.getPassword());

                JPasswordField campoSenhaConfirm = new JPasswordField();
                campoSenhaConfirm.setEchoChar('*');

                JOptionPane.showConfirmDialog(null,campoSenhaConfirm,"Confirmação de senha",JOptionPane.OK_CANCEL_OPTION);
                senhaConfirmUsuario=new String(campoSenhaConfirm.getPassword());
            
                
                // Se os dados do usuário são válidos
                if ( validaSenhaUsuario(senhaUsuario,senhaConfirmUsuario) ){
                    // Alterando dados do usuário selecionado
                    alterarSenhaUsuario(codigoUsuario, senhaUsuario);
                    // Consultando usuários novamente após alteração
                    consultarUsuarios();
                } 
                // Se os dados do aluno não são válidos
                else {
                    JOptionPane.showMessageDialog(rootPane, "Favor inserir dados válidos");
                    // Consultando cursos novamente após alteração
                    consultarUsuarios();
                }                
            }
            // Se não existe uma linha selecionada na tabela
            else {
                JOptionPane.showMessageDialog(rootPane, "Selecione uma linha para ser alterada");
            }
        }
    }//GEN-LAST:event_botaoAlterarSenhaMouseClicked

    private void botaoBloquearDesbloquearMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botaoBloquearDesbloquearMouseClicked

        if ( ! JanelaLogin.papelUsuario.equals("Administrador") ) {
            JOptionPane.showMessageDialog(rootPane, "Ação autorizada somente para administradores");
        }
        else {
        
            // Se existe uma linha selecionada na tabela
            if ( tabelaUsuarios.getSelectedRowCount() > 0 ) {
            
                  // Obtendo o codigo do usuario (coluna 0) da linha selecionada
                codigoUsuario=(String) tabelaUsuarios.getModel().getValueAt(tabelaUsuarios.getSelectedRow(), 0);

                // Obtendo o nome do usuario (coluna 1) da linha selecionada
                nomeUsuario=(String) tabelaUsuarios.getModel().getValueAt(tabelaUsuarios.getSelectedRow(), 1);
              
                // Obtendo o status (coluna 2) do usuario da linha selecionada
                statusUsuario=(String) tabelaUsuarios.getModel().getValueAt(tabelaUsuarios.getSelectedRow(), 2);
              
                if ( bloquearDesbloquearUsuario(codigoUsuario,statusUsuario) ){
                      // Se o status atual é bloqueado então exiba que ele foi desbloqueado
                    if ( statusUsuario.equals("bloqueado") ){
                          JOptionPane.showMessageDialog(rootPane, "Usuário: "+nomeUsuario+ " desbloqueado com êxito");
                    }
                    // Se o status atual NÃO é bloqueado então exiba que ele foi bloqueado
                    else {
                        JOptionPane.showMessageDialog(rootPane, "Usuário: "+nomeUsuario+ " bloqueado com êxito");
                    }
                }
                else {
                    JOptionPane.showMessageDialog(rootPane, "Falha ao executar ação");
                }
              
                // Consultando cursos novamente após alteração
                consultarUsuarios();
            }
            else {
                JOptionPane.showMessageDialog(rootPane, "Selecione um usuário para ser bloqueado ou desbloqueado");
            }
        }
            
    }//GEN-LAST:event_botaoBloquearDesbloquearMouseClicked

    private void tabelaUsuariosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelaUsuariosMouseClicked

        // Obtendo o nome (coluna 1) do usuario da linha selecionada
        nomeUsuario=(String) tabelaUsuarios.getModel().getValueAt(tabelaUsuarios.getSelectedRow(), 1);

        
        // Obtendo o status (coluna 2) do usuario da linha selecionada
        statusUsuario=(String) tabelaUsuarios.getModel().getValueAt(tabelaUsuarios.getSelectedRow(), 2);

        if ( statusUsuario.equals("bloqueado")) {
            // Desocultando botão
            botaoBloquearDesbloquear.setVisible(true);
            // Alterando texto do botão
            botaoBloquearDesbloquear.setText("Desbloquear");
            botaoBloquearDesbloquear.setBackground(Color.YELLOW);
        }
        else if ( statusUsuario.equals("desbloqueado")) {
            // Desocultando botão
            botaoBloquearDesbloquear.setVisible(true);
            // Alterando texto do botão
            botaoBloquearDesbloquear.setText("Bloquear");
            botaoBloquearDesbloquear.setBackground(Color.RED);
        }
        consultarInfoUsuario(nomeUsuario);
    }//GEN-LAST:event_tabelaUsuariosMouseClicked

    private void botaoAlterarPapelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botaoAlterarPapelMouseClicked

        if ( ! JanelaLogin.papelUsuario.equals("Administrador") ) {
            JOptionPane.showMessageDialog(rootPane, "Ação autorizada somente para administradores");
        }
        else {
        
            String codigoPapelUsuario;
            String papelSelecionado;
        
            // Se existe uma linha selecionada na tabela
            if ( tabelaUsuarios.getSelectedRowCount() > 0 ) {
            
                // Obtendo o codigo do usuario (coluna 0) da linha selecionada
                codigoUsuario=(String) tabelaUsuarios.getModel().getValueAt(tabelaUsuarios.getSelectedRow(), 0);

                // Obtendo o papel do usuario (coluna 3) da linha selecionada
                papelUsuario=(String) tabelaUsuarios.getModel().getValueAt(tabelaUsuarios.getSelectedRow(), 3);

                papelSelecionado=comboPapeis.getSelectedItem().toString().split("[-]")[1];
              
                // Obtendo o código (que esta a esquerda do hífen existente na String obtida da comboPapeis  
                codigoPapelUsuario=comboPapeis.getSelectedItem().toString().split("[-]")[0];

                if ( ! papelUsuario.equals(papelSelecionado) ){
            
                    if ( alterarPapelUsuario(codigoUsuario,codigoPapelUsuario) ){
                        JOptionPane.showMessageDialog(rootPane, "Usuário: "+nomeUsuario+ " teve o papel alterado para "+papelSelecionado);
                    }
                    else {
                        JOptionPane.showMessageDialog(rootPane, "Falha ao executar ação");
                    }
                }
                else {
                    JOptionPane.showMessageDialog(rootPane, "Selecione um papel diferente do atual");
                }
                
                // Consultando cursos novamente após alteração
                consultarUsuarios();

            }
            else {
                JOptionPane.showMessageDialog(rootPane, "Selecione um usuário para ter o papel alterado.");
            }
        }
    }//GEN-LAST:event_botaoAlterarPapelMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new JanelaUsuarios().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botaoAlterarNome;
    private javax.swing.JButton botaoAlterarPapel;
    private javax.swing.JButton botaoAlterarSenha;
    private javax.swing.JButton botaoBloquearDesbloquear;
    private javax.swing.JButton botaoConsultaUsuarios;
    private javax.swing.JButton botaoExcluir;
    private javax.swing.JButton botaoInserir;
    private javax.swing.JTextField campoTotalUsuarios;
    private javax.swing.JComboBox<String> comboPapeis;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tabelaAuditoria;
    private javax.swing.JTable tabelaUsuarios;
    // End of variables declaration//GEN-END:variables

   
}
